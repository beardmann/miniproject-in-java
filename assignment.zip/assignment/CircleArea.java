package assignment;
import java.util.Scanner;
public class CircleArea {

	public static void main(String[] args) {
		 Scanner c = new Scanner(System.in);
		 System.out.print(" enter the radius in cm :"); 
		 float radius = c.nextInt();
		 float area = 3.14f * radius*radius;
		 System.out.print("area is\t"+area);
		
	}

}
