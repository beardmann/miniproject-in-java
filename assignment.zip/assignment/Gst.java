package assignment;
import java.util.*;
public class Gst {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
	System.out.print("enter the initial amount:");
	 int initial_cost= sc.nextInt() ;
	 System.out.print(" enter the rate of the gst: ");
	int gst_rate= sc.nextInt();
    int gst_amount = (initial_cost *gst_rate)/100;
	int net_price = initial_cost + gst_amount;
	System.out.println(" your gst charge is "+gst_amount);
	System.out.println(" your have to pay total   "+net_price);

	}

}
