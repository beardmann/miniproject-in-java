package assignment;
import java.util.Scanner;
public class rectanglearea {

	public static void main(String[] args) {
       Scanner s2 = new Scanner(System.in);
       System.out.println("\t\t\tArea of rectangle \n\t ");
       System.out.print("enter the length of the ractangle:");
              int length = s2.nextInt();
              System.out.print("enter the bridth of the ractangle:");
              int bridth = s2.nextInt();
              System.out.print(" area of the rectangle is : "+(length*bridth));
	}

}
