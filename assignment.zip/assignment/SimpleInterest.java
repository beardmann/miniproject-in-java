package assignment;
import java.util.Scanner;
public class SimpleInterest {

	public static void main(String[] args) {
		Scanner s2 = new Scanner(System.in);
		System.out.print("\t\t\t enter the principle amount :");
		int principleamount = s2.nextInt();
		System.out.print("\t\t\tenter the rate:");
		float rate =  s2.nextFloat();
		System.out.print("\t\t\t enter the time in years :");
		int time = s2.nextInt();
		 float si = (principleamount*rate*time)/100;
  System.out.println("simple interst is :"+si);
  System.out.println("total amount is "+(si+principleamount));
		 
		 
		 
		 
	}

}
