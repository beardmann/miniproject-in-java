package assignment;
import java.util.Scanner;
public class trainglearea {

	public static void main(String[] args) {
		Scanner f = new Scanner(System.in);
		System.out.println(" enter the bridth");
		 int b = f.nextInt();
		System.out.println(" enter the height");
        int h  = f.nextInt();
        int c = b*h;
        float area = (1/2f)*c;
        System.out.print(" area of the given parameter is " + area);
	}

}
